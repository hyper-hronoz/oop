public class SecondTask {
    private const int MATRIX_SIZE = 25;


    public void doTask() {
        double[,] areas = new double[MATRIX_SIZE, MATRIX_SIZE];

        for (int i = 0; i < SecondTask.MATRIX_SIZE; i++) {
            for (int j = 0; j < SecondTask.MATRIX_SIZE; j++) {
                Random random = new Random();
                areas[i, j] = random.Next(10); 
            }
        }

        int maxRowIndex = 0;
        int minRowIndex = 0;
        double maxAverangeSum = Double.MinValue;
        double minAverangeSum = Double.MaxValue;

        for (int i = 0; i < SecondTask.MATRIX_SIZE; i++) {
            double averange = 0;
            for (int j = 0; j < SecondTask.MATRIX_SIZE; j++) {
                averange += areas[i, j];
            }
            if (averange > maxAverangeSum) {
                maxAverangeSum = averange;
                maxRowIndex = i;
            }
            if (averange < minAverangeSum) {
                minAverangeSum = averange;
                minRowIndex = i;
            }
            Console.WriteLine();
        }


    } 
}
