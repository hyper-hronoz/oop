public interface IDoTask {
    object getResult();
    void doTask();
}


